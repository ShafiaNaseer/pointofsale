import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../database/local_database.dart';
import '../model/product_model.dart';
import '../pages/product_page.dart';

class ProductForm extends StatefulWidget {
  final Product? product; // Pass the Product object as a parameter

  ProductForm({this.product});
  @override
  _ProductFormState createState() => _ProductFormState();
}

class _ProductFormState extends State<ProductForm> {
  final _productNameController = TextEditingController();
  final _skuIdController = TextEditingController();
  final _costPriceController = TextEditingController();
  final _sellingPriceController = TextEditingController();
  final _retailPriceController = TextEditingController();
  final _quantityController = TextEditingController();
  final _discountController = TextEditingController();
  File? _selectedImage;
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    // If editing an existing product, populate the form fields with its data
    if (widget.product != null) {
      _productNameController.text = widget.product!.name!;
      _skuIdController.text = widget.product!.skuId!;
      _costPriceController.text = widget.product!.costPrice!.toStringAsFixed(2);
      _sellingPriceController.text = widget.product!.sellingPrice!.toStringAsFixed(2);
      _retailPriceController.text = widget.product!.retailPrice!.toStringAsFixed(2);
      _quantityController.text = widget.product!.quantity.toString();
      _discountController.text = widget.product!.discount!.toStringAsFixed(2);
      // Load the existing image if available
      if (widget.product!.imagePath != null) {
        _selectedImage = File(widget.product!.imagePath!);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.product == null ? 'Add Product' : 'Edit Product')),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(26.0),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                _selectedImage != null ?
                  Image.file(
                    _selectedImage!,
                    width: 150,
                    height: 150,
                    fit: BoxFit.cover,
                  ) : Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.3),
                    border: Border.all(color: Colors.black)
                  ),
                  child: Center(
                    child: Icon(Icons.image_not_supported_outlined),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton.icon(
                  icon: Icon(Icons.image),
                  label: Text('Upload Product Image'),
                  onPressed: _pickImage,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _productNameController,
                  labelText: 'Product Name',
                  icon: Icons.label,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _skuIdController,
                  labelText: 'SKU ID',
                  icon: Icons.qr_code,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _costPriceController,
                  labelText: 'Cost Price',
                  icon: Icons.money,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _sellingPriceController,
                  labelText: 'Selling Price',
                  icon: Icons.price_check,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _retailPriceController,
                  labelText: 'Retail Price',
                  icon: Icons.store,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _quantityController,
                  labelText: 'Available Quantity',
                  icon: Icons.format_list_numbered,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 10),
                _buildTextField(
                  controller: _discountController,
                  labelText: 'Discount',
                  icon: Icons.money_off,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Colors.green,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 70, vertical: 20),
                    textStyle: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: Text(widget.product == null ? 'Save this product' : 'Update Product'),
                  onPressed: () async {
                    if(formKey.currentState!.validate()){
                      String? imagePath = _selectedImage?.path;
                      if (imagePath == null || imagePath.isEmpty) {
                        // Display a message if no image is selected
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Please select an image of the product.'),
                          ),
                        );
                      } else {
                        try{
                        int productId = DateTime.now().millisecondsSinceEpoch;
                      Product newProduct = Product(
                        productId: widget.product?.productId ?? productId,
                        name: _productNameController.text,
                        skuId: _skuIdController.text,
                        costPrice: double.parse(_costPriceController.text),
                        sellingPrice: double.parse(_sellingPriceController.text),
                        retailPrice: double.parse(_retailPriceController.text),
                        quantity: int.parse(_quantityController.text),
                        discount: double.parse(_discountController.text),
                        updatedAt: DateTime.now().toString(),
                        createdAt:  widget.product?.createdAt ?? DateTime.now().toString(),
                        imagePath: imagePath,
                      );
                        // Determine whether to add a new product or update an existing one
                        if (widget.product == null) {
                          await ProductDB().saveProduct(newProduct); // Save a new product
                        } else {
                          int? productId = widget.product!.productId;
                          await ProductDB().updateProduct(newProduct, productId! ); // Update an existing product
                        }
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(widget.product == null ? 'Product saved successfully' : 'Product updated successfully'),
                        ),
                      );
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ProductsScreen(),));
                    } catch (e) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text("$e"),
                            ),
                          );
                        }
                    }
                    }
                  },
                ),
                SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    } else {
      print('No image selected.');
    }
  }

  TextFormField _buildTextField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: (value) {
        if (value!.isEmpty) {
          return "Must Fill";
        }
      },
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(12),
        labelText: labelText,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(),
      ),
    );
  }


  @override
  void dispose() {
    _productNameController.dispose();
    _skuIdController.dispose();
    _costPriceController.dispose();
    _sellingPriceController.dispose();
    _retailPriceController.dispose();
    _quantityController.dispose();
    _discountController.dispose();
    super.dispose();
  }
}
