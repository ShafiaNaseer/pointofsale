import "package:flutter/material.dart";
import 'package:pointofsale/widget/products_form.dart';

class CustomFAB extends StatelessWidget {
  final Function onTap;

  CustomFAB({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: () => _showCustomMenu(context),
      child: Icon(Icons.add),
    );
  }

  void _showCustomMenu(BuildContext context) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;
    final position = renderBox.localToGlobal(Offset.zero);

    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(
        position.dx,
        position.dy - size.height * 2, // adjust this value for menu height
        position.dx + size.width,
        position.dy,
      ),
      items: [
        PopupMenuItem(
          child: ListTile(
            leading: Icon(Icons.add),
            title: Text('Add Product'),
            onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => ProductForm())); // To close the menu
            },
          ),
        ),
        PopupMenuItem(
          child: ListTile(
            leading: Icon(Icons.add),
            title: Text('Add Customers'),
            onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => ProductForm())); // To close the menu
            },
          ),
        ),
        PopupMenuItem(
          child: ListTile(
            leading: Icon(Icons.add),
            title: Text('Create Invoice'),
            onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => ProductForm())); // To close the menu
            },
          ),
        ),
        // Add other menu items here
      ],
    );
  }
}
