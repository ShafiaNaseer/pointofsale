import 'package:flutter/material.dart';
import 'package:pointofsale/pages/product_page.dart';

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: Text('Dashboard'),
            decoration: BoxDecoration(
              color: Colors.green,
            ),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Home'),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.person), // Icon for Profile
            title: Text('Profile'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to Profile
            },
          ),
          ListTile(
            leading: Icon(Icons.local_offer),
            title: Text('Products'),
            onTap: () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => ProductsScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.group),
            title: Text('Customers'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to customers
            },
          ),
          ListTile(
            leading: Icon(Icons.shopping_cart),
            title: Text('Orders'),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.payment),
            title: Text('Payments'),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.shopping_bag),
            title: Text('Sales'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to sales
            },
          ),
          ListTile(
            leading: Icon(Icons.shopping_cart),
            title: Text('Purchases'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to purchases
            },
          ),
          ListTile(
            leading: Icon(Icons.store),
            title: Text('Inventory'),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.receipt_long),
            title: Text('Invoices'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to invoices
            },
          ),
          ListTile(
            leading: Icon(Icons.loyalty),
            title: Text('Loyalty Programs'),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.card_giftcard),
            title: Text('Gift Cards & Vouchers'),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.report), // Icon for Reports
            title: Text('Reports'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to Reports
            },
          ),
          ListTile(
            leading: Icon(Icons.account_balance), // Icon for Reports
            title: Text('Tax Report'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to Reports
            },
          ),
          ListTile(
            leading: Icon(Icons.settings), // Icon for Settings
            title: Text('Settings'),
            onTap: () {
              Navigator.pop(context);
              // Navigate to Settings
            },
          ),
          ListTile(
            leading: Icon(Icons.exit_to_app),
            title: Text('Logout'),
            onTap: () {
              // Implement logout logic here
            },
          )

// Add more tabs as per your requirement
        ],
      ),
    );
    // ... [Baki ListTiles yaha]
  }
}
