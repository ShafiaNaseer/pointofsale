import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../model/product_model.dart';

class ProductDB {
  static final ProductDB _instance = ProductDB._internal();

  factory ProductDB() => _instance;
  static Database? _database;

  Future<Database> get database async {
    // If database exists, return database
    if (_database != null) return _database!;
    // If database doesn't exist, create one
    _database = await initDatabase();
    return _database!;
  }

  ProductDB._internal();

  Future initDatabase() async {
    String databasePath = await getDatabasesPath();
    String path = join(databasePath, 'product.db');
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db.execute(
      '''CREATE TABLE products (
      productId INTEGER PRIMARY KEY AUTOINCREMENT,
      imagePath TEXT,
      name TEXT,
      skuId TEXT,
      costPrice REAL,
      sellingPrice REAL,
      retailPrice REAL,
      quantity INTEGER,
      discount REAL,
      createdAt TEXT,
      updatedAt TEXT 
    )''',
    );
  }
// save product into database
  Future<int> saveProduct(Product product) async {
    final dbClient = await database;
    return await dbClient.insert('products', product.toMap());
  }


  // Function to retrieve all products from the 'products' table
  Future<List<Product>> getProducts() async {
    final dbClient = await database;
    final List<Map<String, dynamic>> productList = await dbClient.query('products');
    return productList.map((productMap) => Product.fromMap(productMap)).toList();
  }

  // Function to delete a product by its unique ID
  Future<int> deleteProduct(int productId) async {
    final dbClient = await database;
    return await dbClient.delete(
      'products',
      where: 'productId = ?',
      whereArgs: [productId],
    );
  }

  // Function to update a product
  Future<int> updateProduct(Product product, int productId) async {
    final dbClient = await database;
    return await dbClient.update(
      'products',
      product.toMap(),
      where: 'productId = ?',
      whereArgs: [productId],
    );
  }

}
