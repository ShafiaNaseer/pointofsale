import 'package:flutter/material.dart';
import 'package:pointofsale/pages/homepage.dart';

import 'database/local_database.dart';

void main() {
  runApp(MyApp());
  createDb();
}

createDb() async {
  await ProductDB().initDatabase();
  print('created');
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Point of Sale',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MyHomePage(),
    );
  }
}
