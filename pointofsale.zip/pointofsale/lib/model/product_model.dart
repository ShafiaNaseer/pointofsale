class Product {
  int? productId;
  String? name, skuId, updatedAt, createdAt, imagePath;
  double? costPrice, sellingPrice, retailPrice, discount;
  int? quantity;

  Product({
     this.name,
     this.skuId,
     this.costPrice,
     this.sellingPrice,
     this.retailPrice,
     this.quantity,
     this.discount,
     this.updatedAt,
     this.createdAt,
     this.imagePath,
    this.productId
  });

  // Convert a Product object to a map for database insertion.
  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'name': name,
      'skuId': skuId,
      'costPrice': costPrice,
      'sellingPrice': sellingPrice,
      'retailPrice': retailPrice,
      'quantity': quantity,
      'discount': discount,
      'updatedAt': updatedAt,
      'createdAt': createdAt,
      'imagePath': imagePath,
    };
  }

  // Create a Product object from a map retrieved from the database.
  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      productId: map['productId'],
      name: map['name'],
      skuId: map['skuId'],
      costPrice: map['costPrice'],
      sellingPrice: map['sellingPrice'],
      retailPrice: map['retailPrice'],
      quantity: map['quantity'],
      discount: map['discount'],
      updatedAt: map['updatedAt'],
      createdAt: map['createdAt'],
      imagePath: map['imagePath'],
    );
  }
}
