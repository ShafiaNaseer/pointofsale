import "package:flutter/material.dart";
import "package:pointofsale/pages/product_page.dart";
import "package:pointofsale/widget/customFab.dart";
import "package:pointofsale/widget/menu.dart";
import 'package:pointofsale/widget/products_form.dart';

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 4.0, // Shadow ko prominent banane ke liye
          centerTitle: false, // Title ko center mein nahi rakhne ke liye
          title: Padding(
            padding: const EdgeInsets.symmetric(
                vertical: 8.0,
                horizontal: 16.0), // Thoda padding add karo title ke around
            child: Text(
              'Point of Sale',
              style: TextStyle(
                fontSize: 26.0, // Font size badhaya hai
                fontWeight: FontWeight.bold, // Bold font weight set kiya hai
                letterSpacing: 1.2, // Har character ke beech mein thoda space
              ),
            ),
          ),
          backgroundColor:
              Colors.green[700], // Dark shade of green for the app bar
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(30), // Curved bottom for the app bar
            ),
          ),
        ),
        floatingActionButton: CustomFAB(
          onTap: () => _showCustomMenu(context),
        ),
        drawer: AppDrawer());
  }
}

void _showCustomMenu(BuildContext context) {
  final RenderBox renderBox = context.findRenderObject() as RenderBox;
  final size = renderBox.size;
  final position = renderBox.localToGlobal(Offset.zero);

  showMenu(
    context: context,
    position: RelativeRect.fromLTRB(
      position.dx,
      position.dy - size.height * 2, // adjust this value for menu height
      position.dx + size.width,
      position.dy,
    ),
    items: [
      PopupMenuItem(
        child: ListTile(
          leading: Icon(Icons.add),
          title: Text('Add Product'),
          onTap: () {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => ProductForm())); // To close the menu
          },
        ),
      ),
      // Add other menu items here
    ],
  );
}
