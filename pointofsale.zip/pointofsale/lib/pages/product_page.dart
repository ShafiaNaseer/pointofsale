import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:pointofsale/widget/products_form.dart';
import 'package:syncfusion_flutter_barcodes/barcodes.dart';
import '../database/local_database.dart';
import '../model/product_model.dart';

class ProductsScreen extends StatefulWidget {
  @override
  _ProductsScreenState createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {

  Widget generateBarcodeImage(String skuId) {
     return SfBarcodeGenerator(value: skuId);
  }


  List<Product> _products = [];
  final ProductDB _productDB = ProductDB();
  // Function to load products from the database
  void loadProducts() async {
    List<Product> products = await _productDB.getProducts();
    setState(() {
      _products = products;
    });
  }

  @override
  void initState() {
    super.initState();
    loadProducts(); // Load products when the screen initializes
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Products'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () async {
              Navigator.push(
                context,MaterialPageRoute(
                  builder: (context) => ProductForm()));
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView.builder(
          itemCount: _products.length,
          itemBuilder: (context, index) {
            return Card(
              elevation: 2,
              margin: EdgeInsets.all(8),
              child: ExpansionTile(
                leading: CircleAvatar(
                  backgroundImage: FileImage(File(_products[index].imagePath!)),
                ),
                title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_products[index].name!),
                    Text(
                      '\$${_products[index].sellingPrice!.toStringAsFixed(2)}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text('SKU ID: ${_products[index].skuId}')),
                        const SizedBox(height: 10,),
                        Text('Cost Price: \$${_products[index].costPrice!.toStringAsFixed(2)}'),
                        const SizedBox(height: 10,),
                        Text('Retail Price: \$${_products[index].retailPrice!.toStringAsFixed(2)}'),
                        const SizedBox(height: 10,),
                        Text('Quantity: ${_products[index].quantity}'),
                        const SizedBox(height: 10,),
                        Text('Discount: ${(_products[index].discount!)}'),
                        const SizedBox(height: 10,),
                        Container(
                          height: 50,
                          child: generateBarcodeImage(_products[index].skuId!),
                        )
                      ],
                    ),
                  ),

                  ButtonBar(
                    children: [
                      IconButton(onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ProductForm(product: _products[index]),));
                      }, icon: Icon(Icons.edit, color: Colors.green,)),

                      IconButton(onPressed: () async {
                        print('idddd: ${_products[index].productId!}');
                        // Call the deleteProduct function to delete the product
                        if (_products[index].productId != null) {
                          int deletedRows = await _productDB.deleteProduct(_products[index].productId!);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text("Product deleted"),
                            ),
                          );
                          if (deletedRows > 0) {
                            setState(() {
                              _products.removeAt(index);
                            });
                          }
                        }
                      }, icon: Icon(Icons.delete, color: Colors.red,)),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
